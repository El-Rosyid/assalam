<?php
    use Illuminate\Support\Facades\Storage;
?>

<div class="space-y-4">
    
    <div class="flex items-center justify-between border-b pb-3">
        <h3 class="text-lg font-semibold"><?php echo e($record->title); ?></h3>
        <?php if (isset($component)) { $__componentOriginal986dce9114ddce94a270ab00ce6c273d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal986dce9114ddce94a270ab00ce6c273d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.badge','data' => ['color' => match($record->status) {
            'draft' => 'gray',
            'sending' => 'warning',
            'completed' => 'success',
            'failed' => 'danger',
            default => 'gray'
        }]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(match($record->status) {
            'draft' => 'gray',
            'sending' => 'warning',
            'completed' => 'success',
            'failed' => 'danger',
            default => 'gray'
        })]); ?>
            <?php echo e($record->status_badge); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal986dce9114ddce94a270ab00ce6c273d)): ?>
<?php $attributes = $__attributesOriginal986dce9114ddce94a270ab00ce6c273d; ?>
<?php unset($__attributesOriginal986dce9114ddce94a270ab00ce6c273d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal986dce9114ddce94a270ab00ce6c273d)): ?>
<?php $component = $__componentOriginal986dce9114ddce94a270ab00ce6c273d; ?>
<?php unset($__componentOriginal986dce9114ddce94a270ab00ce6c273d); ?>
<?php endif; ?>
    </div>

    
    <div class="grid grid-cols-2 gap-4 text-sm">
        <div>
            <p class="text-gray-500 dark:text-gray-400">Dibuat Oleh</p>
            <p class="font-medium"><?php echo e($record->user->name ?? '-'); ?></p>
        </div>
        <div>
            <p class="text-gray-500 dark:text-gray-400">Tanggal Dibuat</p>
            <p class="font-medium"><?php echo e($record->created_at->format('d M Y, H:i')); ?></p>
        </div>
        <div>
            <p class="text-gray-500 dark:text-gray-400">Target</p>
            <p class="font-medium"><?php echo e($record->target_type_text); ?></p>
        </div>
        <div>
            <p class="text-gray-500 dark:text-gray-400">Dikirim Pada</p>
            <p class="font-medium"><?php echo e($record->sent_at ? $record->sent_at->format('d M Y, H:i') : '-'); ?></p>
        </div>
    </div>

    
    <div class="grid grid-cols-4 gap-3 py-3 border-y">
        <div class="text-center">
            <p class="text-2xl font-bold text-blue-600"><?php echo e($record->total_recipients); ?></p>
            <p class="text-xs text-gray-500">Total</p>
        </div>
        <div class="text-center">
            <p class="text-2xl font-bold text-green-600"><?php echo e($record->sent_count); ?></p>
            <p class="text-xs text-gray-500">Terkirim</p>
        </div>
        <div class="text-center">
            <p class="text-2xl font-bold text-yellow-600"><?php echo e($record->pending_count); ?></p>
            <p class="text-xs text-gray-500">Pending</p>
        </div>
        <div class="text-center">
            <p class="text-2xl font-bold text-red-600"><?php echo e($record->failed_count); ?></p>
            <p class="text-xs text-gray-500">Gagal</p>
        </div>
    </div>

    
    <div>
        <p class="text-gray-500 dark:text-gray-400 text-sm mb-2">Isi Pesan</p>
        <div class="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 border">
            <p class="whitespace-pre-wrap"><?php echo e($record->message); ?></p>
        </div>
    </div>

    
    <!--[if BLOCK]><![endif]--><?php if($record->status !== 'draft'): ?>
    <div>
        <div class="flex justify-between text-sm mb-1">
            <span class="text-gray-500">Progress Pengiriman</span>
            <span class="font-medium"><?php echo e($record->progress_percentage); ?>%</span>
        </div>
        <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
            <div class="bg-green-600 h-2.5 rounded-full" style="width: <?php echo e($record->progress_percentage); ?>%"></div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\sekolah\resources\views/filament/modals/custom-broadcast-detail.blade.php ENDPATH**/ ?>