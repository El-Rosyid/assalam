<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.academic-year-resource.pages.create-academic-year' => 'App\\Filament\\Resources\\AcademicYearResource\\Pages\\CreateAcademicYear',
    'app.filament.resources.academic-year-resource.pages.edit-academic-year' => 'App\\Filament\\Resources\\AcademicYearResource\\Pages\\EditAcademicYear',
    'app.filament.resources.academic-year-resource.pages.list-academic-years' => 'App\\Filament\\Resources\\AcademicYearResource\\Pages\\ListAcademicYears',
    'app.filament.resources.admin-report-card-resource.pages.admin-report-card-students' => 'App\\Filament\\Resources\\AdminReportCardResource\\Pages\\AdminReportCardStudents',
    'app.filament.resources.admin-report-card-resource.pages.list-admin-report-cards' => 'App\\Filament\\Resources\\AdminReportCardResource\\Pages\\ListAdminReportCards',
    'app.filament.resources.assessment-rating-description-resource.pages.create-assessment-rating-description' => 'App\\Filament\\Resources\\AssessmentRatingDescriptionResource\\Pages\\CreateAssessmentRatingDescription',
    'app.filament.resources.assessment-rating-description-resource.pages.edit-assessment-rating-description' => 'App\\Filament\\Resources\\AssessmentRatingDescriptionResource\\Pages\\EditAssessmentRatingDescription',
    'app.filament.resources.assessment-rating-description-resource.pages.list-assessment-rating-descriptions' => 'App\\Filament\\Resources\\AssessmentRatingDescriptionResource\\Pages\\ListAssessmentRatingDescriptions',
    'app.filament.resources.attendance-record-resource.pages.create-attendance-record' => 'App\\Filament\\Resources\\AttendanceRecordResource\\Pages\\CreateAttendanceRecord',
    'app.filament.resources.attendance-record-resource.pages.edit-attendance-record' => 'App\\Filament\\Resources\\AttendanceRecordResource\\Pages\\EditAttendanceRecord',
    'app.filament.resources.attendance-record-resource.pages.list-attendance-records' => 'App\\Filament\\Resources\\AttendanceRecordResource\\Pages\\ListAttendanceRecords',
    'app.filament.resources.attendance-record-resource.pages.manage-attendance-record' => 'App\\Filament\\Resources\\AttendanceRecordResource\\Pages\\ManageAttendanceRecord',
    'app.filament.resources.custom-broadcast-resource.pages.create-custom-broadcast' => 'App\\Filament\\Resources\\CustomBroadcastResource\\Pages\\CreateCustomBroadcast',
    'app.filament.resources.custom-broadcast-resource.pages.edit-custom-broadcast' => 'App\\Filament\\Resources\\CustomBroadcastResource\\Pages\\EditCustomBroadcast',
    'app.filament.resources.custom-broadcast-resource.pages.list-custom-broadcasts' => 'App\\Filament\\Resources\\CustomBroadcastResource\\Pages\\ListCustomBroadcasts',
    'app.filament.resources.custom-broadcast-resource.pages.view-custom-broadcast' => 'App\\Filament\\Resources\\CustomBroadcastResource\\Pages\\ViewCustomBroadcast',
    'app.filament.resources.custom-broadcast-resource.relation-managers.logs-relation-manager' => 'App\\Filament\\Resources\\CustomBroadcastResource\\RelationManagers\\LogsRelationManager',
    'app.filament.resources.data-guru-resource.pages.create-data-guru' => 'App\\Filament\\Resources\\DataGuruResource\\Pages\\CreateDataGuru',
    'app.filament.resources.data-guru-resource.pages.edit-data-guru' => 'App\\Filament\\Resources\\DataGuruResource\\Pages\\EditDataGuru',
    'app.filament.resources.data-guru-resource.pages.list-data-gurus' => 'App\\Filament\\Resources\\DataGuruResource\\Pages\\ListDataGurus',
    'app.filament.resources.data-kelas-resource.pages.create-data-kelas' => 'App\\Filament\\Resources\\DataKelasResource\\Pages\\CreateDataKelas',
    'app.filament.resources.data-kelas-resource.pages.edit-data-kelas' => 'App\\Filament\\Resources\\DataKelasResource\\Pages\\EditDataKelas',
    'app.filament.resources.data-kelas-resource.pages.list-data-kelas' => 'App\\Filament\\Resources\\DataKelasResource\\Pages\\ListDataKelas',
    'app.filament.resources.data-siswa-resource.pages.create-data-siswa' => 'App\\Filament\\Resources\\DataSiswaResource\\Pages\\CreateDataSiswa',
    'app.filament.resources.data-siswa-resource.pages.edit-data-siswa' => 'App\\Filament\\Resources\\DataSiswaResource\\Pages\\EditDataSiswa',
    'app.filament.resources.data-siswa-resource.pages.list-data-siswas' => 'App\\Filament\\Resources\\DataSiswaResource\\Pages\\ListDataSiswas',
    'app.filament.resources.growth-record-resource.pages.list-growth-records' => 'App\\Filament\\Resources\\GrowthRecordResource\\Pages\\ListGrowthRecords',
    'app.filament.resources.growth-record-resource.pages.manage-growth-records' => 'App\\Filament\\Resources\\GrowthRecordResource\\Pages\\ManageGrowthRecords',
    'app.filament.resources.guru-kelas-resource.pages.list-guru-kelas' => 'App\\Filament\\Resources\\GuruKelasResource\\Pages\\ListGuruKelas',
    'app.filament.resources.monthly-report-broadcast-resource.pages.create-monthly-report-broadcast' => 'App\\Filament\\Resources\\MonthlyReportBroadcastResource\\Pages\\CreateMonthlyReportBroadcast',
    'app.filament.resources.monthly-report-broadcast-resource.pages.edit-monthly-report-broadcast' => 'App\\Filament\\Resources\\MonthlyReportBroadcastResource\\Pages\\EditMonthlyReportBroadcast',
    'app.filament.resources.monthly-report-broadcast-resource.pages.list-monthly-report-broadcasts' => 'App\\Filament\\Resources\\MonthlyReportBroadcastResource\\Pages\\ListMonthlyReportBroadcasts',
    'app.filament.resources.monthly-report-resource.pages.create-monthly-report' => 'App\\Filament\\Resources\\MonthlyReportResource\\Pages\\CreateMonthlyReport',
    'app.filament.resources.monthly-report-resource.pages.edit-monthly-report' => 'App\\Filament\\Resources\\MonthlyReportResource\\Pages\\EditMonthlyReport',
    'app.filament.resources.monthly-report-resource.pages.list-monthly-reports' => 'App\\Filament\\Resources\\MonthlyReportResource\\Pages\\ListMonthlyReports',
    'app.filament.resources.monthly-report-resource.pages.manage-student-reports' => 'App\\Filament\\Resources\\MonthlyReportResource\\Pages\\ManageStudentReports',
    'app.filament.resources.monthly-report-siswa-resource.pages.list-monthly-report-siswas' => 'App\\Filament\\Resources\\MonthlyReportSiswaResource\\Pages\\ListMonthlyReportSiswas',
    'app.filament.resources.monthly-report-siswa-resource.pages.view-monthly-report-siswa' => 'App\\Filament\\Resources\\MonthlyReportSiswaResource\\Pages\\ViewMonthlyReportSiswa',
    'app.filament.resources.mounthly-report-resource.pages.manage-monthly-report' => 'App\\Filament\\Resources\\MounthlyReportResource\\Pages\\ManageMonthlyReport',
    'app.filament.resources.permission-resource.pages.create-permission' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\CreatePermission',
    'app.filament.resources.permission-resource.pages.edit-permission' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\EditPermission',
    'app.filament.resources.permission-resource.pages.list-permissions' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\ListPermissions',
    'app.filament.resources.profile-resource.pages.edit-profile' => 'App\\Filament\\Resources\\ProfileResource\\Pages\\EditProfile',
    'app.filament.resources.profile-resource.pages.list-profiles' => 'App\\Filament\\Resources\\ProfileResource\\Pages\\ListProfiles',
    'app.filament.resources.report-card-resource.pages.list-report-cards' => 'App\\Filament\\Resources\\ReportCardResource\\Pages\\ListReportCards',
    'app.filament.resources.report-card-resource.pages.report-card-students' => 'App\\Filament\\Resources\\ReportCardResource\\Pages\\ReportCardStudents',
    'app.filament.resources.role-resource.pages.create-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\CreateRole',
    'app.filament.resources.role-resource.pages.edit-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\EditRole',
    'app.filament.resources.role-resource.pages.list-roles' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ListRoles',
    'app.filament.resources.sekolah-resource.pages.create-sekolah' => 'App\\Filament\\Resources\\SekolahResource\\Pages\\CreateSekolah',
    'app.filament.resources.sekolah-resource.pages.edit-sekolah' => 'App\\Filament\\Resources\\SekolahResource\\Pages\\EditSekolah',
    'app.filament.resources.sekolah-resource.pages.list-sekolahs' => 'App\\Filament\\Resources\\SekolahResource\\Pages\\ListSekolahs',
    'app.filament.resources.student-assessment-resource.pages.input-student-assessment' => 'App\\Filament\\Resources\\StudentAssessmentResource\\Pages\\InputStudentAssessment',
    'app.filament.resources.student-assessment-resource.pages.list-student-assessments' => 'App\\Filament\\Resources\\StudentAssessmentResource\\Pages\\ListStudentAssessments',
    'app.filament.resources.student-assessment-resource.pages.manage-student-assessments' => 'App\\Filament\\Resources\\StudentAssessmentResource\\Pages\\ManageStudentAssessments',
    'app.filament.resources.student-report-card-resource.pages.list-student-report-cards' => 'App\\Filament\\Resources\\StudentReportCardResource\\Pages\\ListStudentReportCards',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.resources.variable-assessment-resource.pages.create-variable-assessment' => 'App\\Filament\\Resources\\VariableAssessmentResource\\Pages\\CreateVariableAssessment',
    'app.filament.resources.variable-assessment-resource.pages.edit-variable-assessment' => 'App\\Filament\\Resources\\VariableAssessmentResource\\Pages\\EditVariableAssessment',
    'app.filament.resources.variable-assessment-resource.pages.list-variable-assessments' => 'App\\Filament\\Resources\\VariableAssessmentResource\\Pages\\ListVariableAssessments',
    'app.filament.pages.storage-management' => 'App\\Filament\\Pages\\StorageManagement',
    'app.filament.pages.student-dashboard' => 'App\\Filament\\Pages\\StudentDashboard',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.guru-stats-overview' => 'App\\Filament\\Widgets\\GuruStatsOverview',
    'app.filament.widgets.school-stats-overview' => 'App\\Filament\\Widgets\\SchoolStatsOverview',
    'app.filament.widgets.student-growth-chart-widget' => 'App\\Filament\\Widgets\\StudentGrowthChartWidget',
    'app.filament.widgets.student-profile-widget' => 'App\\Filament\\Widgets\\StudentProfileWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Pages\\StorageManagement.php' => 'App\\Filament\\Pages\\StorageManagement',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Pages\\StudentDashboard.php' => 'App\\Filament\\Pages\\StudentDashboard',
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\sekolah\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\AcademicYearResource.php' => 'App\\Filament\\Resources\\AcademicYearResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\AdminReportCardResource.php' => 'App\\Filament\\Resources\\AdminReportCardResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\AssessmentRatingDescriptionResource.php' => 'App\\Filament\\Resources\\AssessmentRatingDescriptionResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\AttendanceRecordResource.php' => 'App\\Filament\\Resources\\AttendanceRecordResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\CustomBroadcastResource.php' => 'App\\Filament\\Resources\\CustomBroadcastResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\DataGuruResource.php' => 'App\\Filament\\Resources\\DataGuruResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\DataKelasResource.php' => 'App\\Filament\\Resources\\DataKelasResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\DataSiswaResource.php' => 'App\\Filament\\Resources\\DataSiswaResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\GrowthRecordResource.php' => 'App\\Filament\\Resources\\GrowthRecordResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\GuruKelasResource.php' => 'App\\Filament\\Resources\\GuruKelasResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\MonthlyReportBroadcastResource.php' => 'App\\Filament\\Resources\\MonthlyReportBroadcastResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\MonthlyReportResource.php' => 'App\\Filament\\Resources\\MonthlyReportResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\MonthlyReportSiswaResource.php' => 'App\\Filament\\Resources\\MonthlyReportSiswaResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\PermissionResource.php' => 'App\\Filament\\Resources\\PermissionResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\ProfileResource.php' => 'App\\Filament\\Resources\\ProfileResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\ReportCardResource.php' => 'App\\Filament\\Resources\\ReportCardResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\RoleResource.php' => 'App\\Filament\\Resources\\RoleResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\SekolahResource.php' => 'App\\Filament\\Resources\\SekolahResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\StudentAssessmentResource.php' => 'App\\Filament\\Resources\\StudentAssessmentResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\StudentReportCardResource.php' => 'App\\Filament\\Resources\\StudentReportCardResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Resources\\VariableAssessmentResource.php' => 'App\\Filament\\Resources\\VariableAssessmentResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\sekolah\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Widgets\\GuruStatsOverview.php' => 'App\\Filament\\Widgets\\GuruStatsOverview',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Widgets\\SchoolStatsOverview.php' => 'App\\Filament\\Widgets\\SchoolStatsOverview',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Widgets\\StudentGrowthChartWidget.php' => 'App\\Filament\\Widgets\\StudentGrowthChartWidget',
    'C:\\laragon\\www\\sekolah\\app\\Filament\\Widgets\\StudentProfileWidget.php' => 'App\\Filament\\Widgets\\StudentProfileWidget',
    0 => 'App\\Filament\\Widgets\\SchoolStatsOverview',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\sekolah\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);