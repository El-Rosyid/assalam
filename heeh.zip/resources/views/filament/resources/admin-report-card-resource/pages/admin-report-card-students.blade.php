<x-filament-panels::page>
    <!-- Students Table -->
    {{ $this->table }}
</x-filament-panels::page>