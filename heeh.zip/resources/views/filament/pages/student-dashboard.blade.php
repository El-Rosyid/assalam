<x-filament-panels::page>
    <!-- Widgets akan di-render otomatis oleh Filament -->
</x-filament-panels::page>
