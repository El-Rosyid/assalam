<div class="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
    <div class="prose dark:prose-invert max-w-none">
        <div class="bg-white dark:bg-gray-700 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-600">
            <div class="whitespace-pre-wrap text-sm">{{ $message }}</div>
        </div>
    </div>
</div>
